C:\ProgramData\MySQL\MySQL Server 8.0\Uploads

store_gangwon.txt 파일과 housedeal_data 파일은 위의 경로에 두어야 합니다.
