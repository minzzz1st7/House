package com.ssafy.dto;

public class EnvDto {
	
	String sidogunCode;
	String dongCode;
	String name;
	String typeCode;
	String typeName;
	String address;
	
	public String getSidogunCode() {
		return sidogunCode;
	}
	public void setSidogunCode(String sidogunCode) {
		this.sidogunCode = sidogunCode;
	}
	public String getDongCode() {
		return dongCode;
	}
	public void setDongCode(String dongCode) {
		this.dongCode = dongCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
