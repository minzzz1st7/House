package com.ssafy.service;

import java.util.List;

import com.ssafy.dto.EnvDto;

public interface EnvService {
	public List<EnvDto> searchAll(String sidogun);
}
